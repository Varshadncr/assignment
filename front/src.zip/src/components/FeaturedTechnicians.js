import React, { useState, useEffect } from "react";
import "./FeaturedTechnicians.css"; // Add custom styling for the component

const FeaturedTechnicians = () => {
  const [technicians, setTechnicians] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch featured technicians when the component mounts
  useEffect(() => {
    fetch("http://localhost:5000/api/technicians/featured") // Replace with your actual API endpoint
      .then((response) => response.json())
      .then((data) => {
        setTechnicians(data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching featured technicians:", error);
        setLoading(false);
      });
  }, []);

  return (
    <div className="technician-carousel">
      {loading ? (
        <p>Loading featured technicians...</p>
      ) : (
        technicians.length > 0 ? (
          <div className="technician-cards">
            {technicians.map((technician) => (
              <div key={technician.id} className="technician-card">
                <img
                  src={technician.photo}
                  alt={technician.name}
                  className="technician-photo"
                />
                <h3 className="technician-name">{technician.name}</h3>
                <p className="technician-specialization">
                  Specialization: {technician.specialization}
                </p>
                <p className="technician-rating">
                  Rating: {technician.rating}
                </p>
                <p className="technician-description">
                  {technician.description}
                </p>
                <button className="contact-button">Contact</button>
              </div>
            ))}
          </div>
        ) : (
          <p>No featured technicians available.</p>
        )
      )}
    </div>
  );
};

export default FeaturedTechnicians;
