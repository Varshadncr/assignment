import React, { useState, useEffect } from "react";

const SearchBar = () => {
  const [appliance, setAppliance] = useState("");
  const [suggestions, setSuggestions] = useState([]);

  useEffect(() => {
    if (appliance.length > 2) {
      fetch(`http://localhost:5000/api/appliances/search?query=${appliance}`)
        .then((response) => response.json())
        .then((data) => setSuggestions(data))
        .catch((error) => console.error("Error fetching appliances:", error));
    }
  }, [appliance]);

  const handleChange = (event) => {
    setAppliance(event.target.value);
  };

  return (
    <div className="search-bar">
      <label htmlFor="appliance">Search Appliance:</label>
      <input
        type="text"
        id="appliance"
        value={appliance}
        onChange={handleChange}
        placeholder="Enter appliance type (e.g., Refrigerator)"
      />
      {suggestions.length > 0 && (
        <ul className="suggestions">
          {suggestions.map((suggestion, index) => (
            <li key={index}>{suggestion}</li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SearchBar;
