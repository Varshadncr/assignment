import React, { useState, useEffect } from "react";

const LocationDropdown = () => {
  const [locations, setLocations] = useState([]);

  useEffect(() => {
    // Fetch locations from the backend API
    fetch("http://localhost:5000/api/locations")
      .then((response) => response.json())
      .then((data) => setLocations(data))
      .catch((error) => console.error("Error fetching locations:", error));
  }, []);

  return (
    <div className="location-dropdown">
      <label htmlFor="location">Select Location:</label>
      <select id="location" name="location">
        {locations.length > 0 ? (
          locations.map((location, index) => (
            <option key={index} value={location}>
              {location}
            </option>
          ))
        ) : (
          <option value="">Loading locations...</option>
        )}
      </select>
    </div>
  );
};

export default LocationDropdown;
