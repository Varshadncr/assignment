import React from 'react';
import './styles.css'; // Import your styling file
import LocationDropdown from './components/LocationDropdown';
import SearchBar from './components/SearchBar';
import LoginUser from './components/LoginUser';
import LoginTechnician from './components/LoginTechnician';
import FeaturedTechnicians from './components/FeaturedTechnicians';

function App() {
  return (
    <div className="App">
      {/* Header or Landing Page Section */}
      <header>
        <h1>Welcome to the Technician Finder</h1>
        <p>Find technicians for your home appliances easily</p>
      </header>

      {/* Location and Search Section */}
      <div className="search-section">
        <LocationDropdown />
        <SearchBar />
      </div>

      {/* Featured Technicians Section */}
      <div className="featured-technicians">
        <h2>Featured Technicians</h2>
        <FeaturedTechnicians />
      </div>

      {/* Login Sections */}
      <div className="login-section">
        <h2>User Login</h2>
        <LoginUser />

        <h2>Technician Login</h2>
        <LoginTechnician />
      </div>
    </div>
  );
}

export default App;
