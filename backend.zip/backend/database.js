const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Create or open a database
const db = new sqlite3.Database(path.join(__dirname, 'nviri.db'), (err) => {
    if (err) {
        console.error('Error opening database:', err);
    } else {
        console.log('Database connected');
    }
});

// Create tables if they do not exist
const createTables = () => {
    const locationTable = `
    CREATE TABLE IF NOT EXISTS locations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL
    );
    `;
    const applianceTable = `
    CREATE TABLE IF NOT EXISTS appliances (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT NOT NULL
    );
    `;
    const technicianTable = `
    CREATE TABLE IF NOT EXISTS technicians (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        photo TEXT,
        specialization TEXT,
        rating INTEGER,
        description TEXT,
        location_id INTEGER,
        contact TEXT,
        FOREIGN KEY(location_id) REFERENCES locations(id)
    );
    `;
    const userTable = `
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    );
    `;
    const technicianLoginTable = `
    CREATE TABLE IF NOT EXISTS technician_login (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        business_name TEXT NOT NULL
    );
    `;
    
    db.run(locationTable);
    db.run(applianceTable);
    db.run(technicianTable);
    db.run(userTable);
    db.run(technicianLoginTable);
};

createTables();

module.exports = db;
