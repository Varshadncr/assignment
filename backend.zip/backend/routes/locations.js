const express = require('express');
const db = require('../database');
const router = express.Router();

router.get('/locations', (req, res) => {
    const query = 'SELECT * FROM locations';
    db.all(query, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(rows);
    });
});

module.exports = router;
