const express = require('express');
const db = require('../database');
const router = express.Router();

router.get('/technicians', (req, res) => {
    const query = 'SELECT * FROM technicians LIMIT 5';
    db.all(query, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(rows);
    });
});

module.exports = router;
