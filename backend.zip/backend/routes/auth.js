const express = require('express');
const db = require('../database');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const router = express.Router();

// User Login
router.post('/login-user', (req, res) => {
    const { email, password } = req.body;
    const query = 'SELECT * FROM users WHERE email = ?';
    
    db.get(query, [email], async (err, row) => {
        if (err || !row) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        const isMatch = await bcrypt.compare(password, row.password);
        if (isMatch) {
            const token = jwt.sign({ id: row.id }, 'secret_key', { expiresIn: '1h' });
            res.json({ message: 'Login successful', token });
        } else {
            res.status(401).json({ message: 'Invalid email or password' });
        }
    });
});

// Technician Login
router.post('/login-technician', (req, res) => {
    const { email, password } = req.body;
    const query = 'SELECT * FROM technician_login WHERE email = ?';
    
    db.get(query, [email], async (err, row) => {
        if (err || !row) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        const isMatch = await bcrypt.compare(password, row.password);
        if (isMatch) {
            const token = jwt.sign({ id: row.id }, 'secret_key', { expiresIn: '1h' });
            res.json({ message: 'Login successful', token });
        } else {
            res.status(401).json({ message: 'Invalid email or password' });
        }
    });
});

module.exports = router;
