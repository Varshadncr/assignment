const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const locationsRoutes = require('./routes/locations');
const techniciansRoutes = require('./routes/technicians');
const authRoutes = require('./routes/auth');
const db = require('./database');

const app = express();
const port = 5000;

app.use(cors());
app.use(bodyParser.json());
app.use('/api', locationsRoutes);
app.use('/api', techniciansRoutes);
app.use('/api', authRoutes);

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
